module.exports = {
  token: "MTExMjA1NzEwMTEwNDE5MzU5Ng.GTeT_N.JMoEkslfa9JAL0Gv0_E3ZfS_u5ag_m8zb9U6Y8",
  ticketChannel: "1117368744876965970",
  ticketRoles: ["1117368552610086942"],
  ticketCategory: "1117368619014299698",
  guildId: "1116427643928195262",
};
