const { Client } = require("discord.js");
const { token, guildId } = require("./settings");

const client = new Client({
  intents: ["GUILDS", "GUILD_MEMBERS", "GUILD_MESSAGES"],
});

client.on("ready", async () => {
  console.log(`${client.user.username} is Online`);
  let guild = client.guilds.cache.get(guildId);
  if (guild) {
    await guild.commands.set([
      {
        name: "ping",
        description: `test ping of bot`,
        type: "CHAT_INPUT",
      },
      {
        name: "setup",
        description: `setup ticket system`,
        type: "CHAT_INPUT",
      },
    ]);
  }

client.user.setActivity('WarumSoMad ', { type: 'LISTENING' });;


  
  // loading ticket system
  require("./ticket_system")(client);
})




const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => res.send('Hello World!'));

app.listen(port, () => console.log(`Example app listening at http://localhost:${port}`));




client.login(token);



